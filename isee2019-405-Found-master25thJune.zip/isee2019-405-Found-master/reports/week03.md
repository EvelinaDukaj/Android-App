#  __405-FOUND__
---
## __Week report__
### __Section 1:__
No previous report.

### __Section 2:__

 #### 2.1. What we did.
 During the last week, we went throw the first steps of our team set up, and also worked on the first requirements of our project, which were:

- Come up with a name for the team.
- Decide which project will fit better with the team, in terms of interest and expertise that we currently have.
- Develop a logo for the team
- Prepare a team presentation.
- Develop a blog in which we will report our project progress.
- Write blog content
- Establish Channels of communication for teamwork and for project management.
- Status report.

#### 2.2 What worked:

- Establish the first mode of communication in order to get the team in contact.
- Meetings for decision making and start with some activities.
- Distribute activities equally to speed up the workflow.
- Blog upload.
- First GitHub push.

#### 2.3 What we learned:

- How to use Markdown language to give format to README files and write Blogs.
- How to navigate the GitHub window.
- Tools present on the market for team management (Asana, Slack).
- It’s a good technique for the team to gain confidence in each other, to have lunch together.

#### 2.4 What trouble we had:

- To start working together as a team, because we didn’t know each other.
- To decide the best mode of communication.
- To assign tasks, because at the beginning we weren’t sure about what needs to be done and a set workflow for the tasks.

#### 2.5 Where we got stuck:

Since its the first step, there are not major things where we are stuck.


#### 2.6 Roles and responsibilities:

As group decisions, we selected the project and established the team name.

|TEAM MEMBER | Evelina | Mariam | Mohammed | Ronald |
| :------: | :------: | :------: | :------: | :------: |
| __ROLE__       | _Developer_ |_Scrum Master_ | _Developer_|_Scrum Master_ |
| __ACTIVITIES__       |Blog development | Logo| Blog development|Logo |
|     |Blog Content |Team presentation |Blog Content |  Status report |
|     | |Blog Content | |Blog Content |
|     | |Channels of team management | |Channels of communication |

### __Section 3:__

#### 3.1 Plans:

- Establish meeting frequencies.
- Catch-Up meeting.

#### 3.2 Goals:

- Use of the Stand-up meeting format as a communication medium, and as a way to keep track of team activities.
- Get a clear set of requirements from the meeting with the client.
- Write the first set of user stories.

### __Section 4:__

Agenda for the meeting with the TA.

#### 4.1 As a Customer

Problem description: (10 minutes)
- Explanation of the problem.
- Questions about the problem.

#### 4.2 As a mentor:

Questions about project: (5 minutes)
- Is it better to start with a mockup of one functionality or a user interface?
- There must be always working software or mockup presentations are allowed?
- Should we have user cases/stories after the first meeting?
