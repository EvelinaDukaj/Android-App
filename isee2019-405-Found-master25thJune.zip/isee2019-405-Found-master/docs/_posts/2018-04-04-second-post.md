---
layout: post
title: "ISEE 2018 -- Second Post"
date: 2018-04-04
---

To validate some of the configuration settings, I just created a second sample post. It shows now show up in the list of Blog entries, located at <https://dbse-teaching.github.io/isee2018/blog>.

Let's see ;-)
