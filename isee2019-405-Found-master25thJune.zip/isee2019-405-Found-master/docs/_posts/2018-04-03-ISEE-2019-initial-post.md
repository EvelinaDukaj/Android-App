---
layout: post
title: "ISEE 2019 -- Initial Blog Post"
date: 2018904-12
---

It's done! The initial Blog post of the ISEE lecture in summer term 2019 -- powered by [Jekyll](http://jekyllrb.com).
Note that you can easily use Markdown to author your posts. This should make your life much more easier---Wooohooo!

One more word about markdown: Is is a really easy-to-learn markup language, similar to those used in Wikis.
Here is a link to all important command on one page: [Markdown Cheat Sheet](http://packetlife.net/media/library/16/Markdown.pdf).

Additionally, there is a great web page with lots of examples for using Markdown, including how to integrate images, videos etc.
Here is the link: [Markdown reference](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

Just as a brief example since I think you will need that quite often: Below you can find an image with a relative reference to its path.

<span align="center">
![Deadline image]({{site.baseurl}}/images/phdcomic-deadlines.gif "Remind the deadlines")
</span>

You can even add an image inline ![Deadline image]({{site.baseurl}}/images/blob.png "Beware of the Blob"){:height="30%" width="30%"}., which means that it will appear within the text, directly at the place where you located the link. And, it is even resized ;)
