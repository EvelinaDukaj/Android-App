![companylogo]({{site.baseurl}}/images/405.jpeg)

# Our Team

![eva]({{site.baseurl}}/images/eva.png)
Evelina Dukaj

An Electronics Engineer from Albania, who has a deep affection for mathematics and exact sciences. She has experience in web design and communications process. Apart from work she loves to cook and try new cusines from around the world.

![mariam]({{site.baseurl}}/images/mariam.png)
Mariam Riaz

Mariam is a Mechanical engineer who has gained major Management and Analytics skills by working through many roles in a major FMCG of the world. She loves to travel around and interact with new people.

![nadeem]({{site.baseurl}}/images/nadeem.png)
Mohammed Nadeem

Mohammed is also an electronics Engineer, he has gained a vast experience in IT industry by working in some Major IT firms in India. 
He loves coding and gaming.

![ronald]({{site.baseurl}}/images/ronald.png)
Ronald Mendez

A Industry 4.0 Enthusiast from Ecaduor, who has worked in different areas of textile and electronics assembly industry. He wants to combine the best of both mechanical and computer science world and contribute in the changing dynamics of industries.

## Why money control?


![saving pig]({{site.baseurl}}/images/pig.png)  

We have chosen to develop money control as we consider that to be an important issue nowadays for people. As students we face it very difficult to maintain an active life with our budget. So we thought that who can better than us give people solutions for this topic.

## Current Roles and Responsibilities ![roles]({{site.baseurl}}/images/penpaper.png)


* Evelina : has experience in front-end design, and she also has good detail attention, which is a great combination when you are developing the User Interface

* Mariam: Is very organized and also have natural people skills which will help us to obtain the right information from the customer, that will lead us to the build a useful product

* Mohammed: Since he has experience and devotion for code writing, he is going to be developing the back-end of the project and also helping with the design of User Interface flow

* Ronald: has experience in team work and management, also he likes to just play with the software tools without any directions, so that he will be helping with the requirements gathering and also with the testing

We are an agile team and we will be changing roles and responsibilities each week, for each one of us to contribute equally and learn every aspect of software development.


## Communication ![telephone]({{site.baseurl}}/images/telephone.png)

For fast and effective communication we are establishing some channels and also a schedule for us to meet to keep us on track.

* WhatsApp as an easy and fast way to send each other short pieces of information and also to organize the meetings.

* GitHub, offers us the possibility to manage the technical aspects of the  project.

* Weekly Meet-ups, will be used to work together to work on app development, blog and presentations.
